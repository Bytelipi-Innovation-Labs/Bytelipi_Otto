// Animated faces + Wi-Fi Access Point + web dashboard
// Waveshare 1.5inch OLED (128x128, SSD1327, SPI) on ESP32-C3 Super Mini
//
// 1. Upload this sketch.
// 2. On your phone/PC connect to Wi-Fi  "AnimatedFace"  (password 12345678).
// 3. Open  http://192.168.4.1  in a browser and tap an expression.
//
// On power-up the OLED first shows the Wi-Fi name, password and address for 5 seconds,
// then switches to the "neutral" face and waits for you to change it from the dashboard.
//
// Wiring: VCC-3V3, GND-GND, DIN-GPIO6, CLK-GPIO4, CS-GPIO7, DC-GPIO3, RST-GPIO10

#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <WebServer.h>
#include <U8g2lib.h>
#include <animated_faces.h>

// ---------- settings you can change ----------
const char* AP_SSID = "AnimatedFace";
const char* AP_PASS = "12345678";      // must be 8+ characters (or "" for an open network)
constexpr uint32_t AUTO_INTERVAL_MS = 4000;
constexpr uint32_t INFO_SCREEN_MS = 5000;   // how long the Wi-Fi info screen is shown at start
// ---------------------------------------------

constexpr int PIN_SCK = 4, PIN_MISO = 5, PIN_MOSI = 6;
constexpr int PIN_CS = 7, PIN_DC = 3, PIN_RST = 10;

U8G2_SSD1327_WS_128X128_F_4W_HW_SPI u8g2(U8G2_R0, PIN_CS, PIN_DC, PIN_RST);
WebServer server(80);

constexpr int Y_OFFSET = (128 - animated_faces::Height) / 2;
static uint8_t raster[animated_faces::FrameBytes];
animated_faces::Player player(0);

const char* currentName = nullptr;
bool autoCycle = false;
unsigned autoIndex = 0;
uint32_t autoChangedAt = 0;

void selectExpression(const char* name) {
  player.Select(name, millis(), true);
  currentName = name;
  Serial.println(name);
}

// Returns the valid expression name matching the text, or nullptr.
const char* findExpression(const String& text) {
  for (unsigned i = 0; i < animated_faces::ExpressionCount; ++i)
    if (text == animated_faces::ExpressionName(i)) return animated_faces::ExpressionName(i);
  return nullptr;
}

String buildPage() {
  String h;
  h.reserve(4096);
  h += F("<!doctype html><html><head><meta charset='utf-8'>"
         "<meta name='viewport' content='width=device-width,initial-scale=1'>"
         "<title>Animated Face</title><style>"
         "body{font-family:system-ui,sans-serif;background:#111;color:#eee;margin:0;padding:16px;text-align:center}"
         "h1{font-size:20px}"
         ".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;max-width:640px;margin:16px auto}"
         "button{padding:14px 6px;font-size:15px;border:0;border-radius:10px;background:#2a2a2a;color:#eee}"
         "button.on{background:#2e7d32}"
         "button:active{background:#444}"
         ".auto{background:#1565c0}.auto.on{background:#2e7d32}"
         "</style></head><body><h1>Animated Face</h1>"
         "<button id='auto' class='auto' onclick='toggleAuto()'>Auto cycle: off</button>"
         "<div class='grid'>");
  for (unsigned i = 0; i < animated_faces::ExpressionCount; ++i) {
    const char* n = animated_faces::ExpressionName(i);
    h += F("<button data-e='"); h += n; h += F("' onclick=\"setE('"); h += n; h += F("')\">");
    h += n; h += F("</button>");
  }
  h += F("</div><script>"
         "function mark(s){document.querySelectorAll('.grid button').forEach(b=>"
         "b.classList.toggle('on',b.dataset.e===s.e));"
         "var a=document.getElementById('auto');a.classList.toggle('on',s.auto);"
         "a.textContent='Auto cycle: '+(s.auto?'on':'off');window.auto=s.auto}"
         "function setE(n){fetch('/set?e='+n).then(r=>r.json()).then(mark)}"
         "function toggleAuto(){fetch('/auto?on='+(window.auto?0:1)).then(r=>r.json()).then(mark)}"
         "function poll(){fetch('/state').then(r=>r.json()).then(mark).catch(()=>{})}"
         "poll();setInterval(poll,2000);"
         "</script></body></html>");
  return h;
}

String stateJson() {
  String s = F("{\"e\":\"");
  s += currentName;
  s += F("\",\"auto\":");
  s += autoCycle ? F("true") : F("false");
  s += F("}");
  return s;
}

void handleRoot()  { server.send(200, "text/html", buildPage()); }
void handleState() { server.send(200, "application/json", stateJson()); }

void handleSet() {
  const char* name = findExpression(server.arg("e"));
  if (!name) { server.send(400, "application/json", "{\"error\":\"unknown expression\"}"); return; }
  autoCycle = false;               // a manual choice stops auto cycling
  selectExpression(name);
  server.send(200, "application/json", stateJson());
}

void handleAuto() {
  autoCycle = server.arg("on") == "1";
  autoChangedAt = millis();
  server.send(200, "application/json", stateJson());
}

void showInfoScreen() {
  String url = "http://" + WiFi.softAPIP().toString();
  u8g2.clearBuffer();
  u8g2.setDrawColor(1);
  u8g2.setFont(u8g2_font_6x12_tf);
  u8g2.drawStr(0, 12, "Connect to Wi-Fi:");
  u8g2.drawStr(0, 30, "Name:");
  u8g2.drawStr(0, 43, AP_SSID);
  u8g2.drawStr(0, 61, "Password:");
  u8g2.drawStr(0, 74, strlen(AP_PASS) ? AP_PASS : "(open network)");
  u8g2.drawStr(0, 92, "Then open:");
  u8g2.drawStr(0, 105, url.c_str());
  u8g2.sendBuffer();
}

void setup() {
  Serial.begin(115200);
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, PIN_CS);
  u8g2.begin();
  u8g2.setContrast(255);

  WiFi.mode(WIFI_AP);
  bool ok = WiFi.softAP(AP_SSID, AP_PASS, 1);   // fixed channel 1
  WiFi.setTxPower(WIFI_POWER_8_5dBm);           // fixes Wi-Fi on many C3 Super Mini boards
  Serial.println(ok ? "AP started" : "AP FAILED");
  Serial.print("AP started. Open http://");
  Serial.println(WiFi.softAPIP());

  server.on("/", handleRoot);
  server.on("/state", handleState);
  server.on("/set", handleSet);
  server.on("/auto", handleAuto);
  server.begin();

  // 1) Show Wi-Fi name, password and address for a few seconds
  showInfoScreen();
  uint32_t start = millis();
  while (millis() - start < INFO_SCREEN_MS) {
    server.handleClient();   // dashboard already works during this time
    delay(5);
  }

  // 2) Then show the default face and wait for changes from the dashboard
  selectExpression(animated_faces::ExpressionName(0));   // "neutral"
  player.Invalidate();                                   // force the first face frame to draw
}

void loop() {
  server.handleClient();

  uint32_t now = millis();
  if (autoCycle && now - autoChangedAt >= AUTO_INTERVAL_MS) {
    autoChangedAt = now;
    autoIndex = (autoIndex + 1) % animated_faces::ExpressionCount;
    selectExpression(animated_faces::ExpressionName(autoIndex));
  }

  if (player.Draw(now, raster, sizeof(raster))) {
    u8g2.clearBuffer();
    u8g2.setDrawColor(1);
    for (unsigned y = 0; y < animated_faces::Height; ++y)
      for (unsigned x = 0; x < animated_faces::Width; ++x)
        if (raster[y * 16 + x / 8] & (0x80 >> (x % 8)))
          u8g2.drawPixel(x, y + Y_OFFSET);
    u8g2.sendBuffer();
  }
  delay(5);
}
