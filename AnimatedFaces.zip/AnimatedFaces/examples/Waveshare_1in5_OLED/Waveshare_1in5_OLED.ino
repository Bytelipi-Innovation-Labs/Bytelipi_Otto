// Animated faces on Waveshare 1.5inch OLED (128x128, SSD1327, SPI)
// Board: ESP32-C3 Super Mini  (Tools > Board > "ESP32C3 Dev Module", USB CDC On Boot = Enabled)
// Library needed: U8g2 (install from Library Manager)
//
// Wiring (module default is 4-wire SPI):
//   OLED VCC -> 3V3     OLED GND -> GND
//   OLED DIN -> GPIO6   (MOSI)
//   OLED CLK -> GPIO4   (SCK)
//   OLED CS  -> GPIO7
//   OLED DC  -> GPIO3
//   OLED RST -> GPIO10

#include <Arduino.h>
#include <SPI.h>
#include <U8g2lib.h>
#include <animated_faces.h>

constexpr int PIN_SCK = 4, PIN_MISO = 5, PIN_MOSI = 6;
constexpr int PIN_CS = 7, PIN_DC = 3, PIN_RST = 10;

U8G2_SSD1327_WS_128X128_F_4W_HW_SPI u8g2(U8G2_R0, PIN_CS, PIN_DC, PIN_RST);

// Face frame is 128x48; place it vertically centered on the 128x128 screen.
constexpr int Y_OFFSET = (128 - animated_faces::Height) / 2;  // 40

static uint8_t raster[animated_faces::FrameBytes];  // 768 bytes
animated_faces::Player player(0);
unsigned expression = 0;
uint32_t changedAt = 0;

void setup() {
  Serial.begin(115200);
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, PIN_CS);
  u8g2.begin();
  u8g2.setContrast(255);
  player.Select(animated_faces::ExpressionName(0), millis(), true);
}

void loop() {
  uint32_t now = millis();

  // Change expression every 4 seconds. Replace with your own logic:
  // player.Select("happy", now);  // names: see ExpressionName(0..20)
  if (now - changedAt >= 4000) {
    changedAt = now;
    expression = (expression + 1) % animated_faces::ExpressionCount;
    player.Select(animated_faces::ExpressionName(expression), now, true);
    Serial.println(animated_faces::ExpressionName(expression));
  }

  if (player.Draw(now, raster, sizeof(raster))) {
    u8g2.clearBuffer();
    u8g2.setDrawColor(1);
    for (unsigned y = 0; y < animated_faces::Height; ++y)
      for (unsigned x = 0; x < animated_faces::Width; ++x)
        if (raster[y * 16 + x / 8] & (0x80 >> (x % 8)))
          u8g2.drawPixel(x, y + Y_OFFSET);
    u8g2.sendBuffer();
  }
  delay(10);
}
